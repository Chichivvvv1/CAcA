// ── Config Worker ─────────────────────────────────────────────────
const WORKER_URL = 'https://proud-tooth-3fe0.roleplayrp.workers.dev';
window.WORKER_URL = WORKER_URL;

// ── Thème clair/sombre — appliqué immédiatement pour éviter le flash ──
(function initTheme() {
  const saved = localStorage.getItem('theme') || 'dark';
  document.documentElement.setAttribute('data-theme', saved);
})();

// Jeton de session signé par le Worker (stocké à part de inno_user, qui est réécrit par les pages
// et synchronisé avec Firestore : le jeton ne doit JAMAIS y figurer).
function getToken() { return localStorage.getItem('inno_token') || ''; }
function clearSession() { localStorage.removeItem('inno_user'); localStorage.removeItem('inno_token'); }
function _onAuthPage() { return /\/(login|callback|banned)(\.html)?$/.test(location.pathname); }

async function callWorker(path, body) {
  const headers = { 'Content-Type': 'application/json' };
  const token = getToken();
  if (token) headers['Authorization'] = 'Bearer ' + token;
  const res = await fetch(WORKER_URL + path, { method: 'POST', headers, body: JSON.stringify(body) });
  if (!res.ok) {
    let data = {};
    try { data = await res.json(); } catch(_) {}
    // Banni : on coupe la session et on affiche la page dédiée
    if (res.status === 403 && data.banned) {
      clearSession();
      if (!/banned/.test(location.pathname)) location.replace('banned.html');
    }
    // Session absente/expirée : retour à la connexion
    if (res.status === 401 && data.code === 'no_session' && !_onAuthPage()) {
      clearSession();
      location.replace('login.html');
    }
    const err = new Error(data.error || `Worker ${path}: ${res.status}`);
    err.status = res.status; err.data = data;
    throw err;
  }
  return res.json();
}

// ── Garde des pages réservées au dev ─────────────────────────────────
// Cache la page, demande au Worker (qui vérifie le jeton signé) et redirige les non-autorisés vers
// l'accueil. À utiliser ainsi :  requireDev().then(() => { ...initialisation de la page... });
// Les appels de la page ne partent qu'APRÈS validation : un simple chargement compte donc pour 1 seul essai.
function requireDev() {
  document.documentElement.style.visibility = 'hidden';
  return new Promise((resolve) => {
    if (!getUser() || !getToken()) { clearSession(); location.replace('login.html'); return; }
    callWorker('/api/auth/is-dev', {}).then(() => {
      document.documentElement.style.visibility = '';
      resolve(true);
    }).catch((e) => {
      if (e.data && e.data.banned) return;   // callWorker a déjà redirigé vers banned.html
      if (e.status === 403 || e.status === 401) { location.replace('index.html'); return; }
      document.documentElement.style.visibility = '';
      document.body.innerHTML = '<p style="font-family:sans-serif;padding:40px;color:#888">Vérification impossible pour le moment (serveur injoignable). Réessayez dans un instant.</p>';
    });
    // Ne résout jamais en cas de refus : le code de la page ne s'exécute pas.
  });
}

// ── Auth helper ───────────────────────────────────────────────────
function getUser() {
  try { return JSON.parse(localStorage.getItem('inno_user') || 'null'); } catch(_) { return null; }
}
function getUserId() { return getUser()?.discordId || null; }

// ── Webhook ───────────────────────────────────────────────────────
async function sendWebhook(type, embeds, content, image, danger) {
  const u = getUser();
  return callWorker('/api/webhook', { type, embeds, content, image, danger, discordId: u?.discordId, actorTag: u?.pseudo });
}

// ── ImgBB ─────────────────────────────────────────────────────────
async function uploadImage(imageBase64, name) {
  return callWorker('/imgbb', { image: imageBase64, name });
}

// ── Casier Discord ────────────────────────────────────────────────
async function postCasierDiscord(data) {
  return callWorker('/casier-discord', data);
}
async function deleteDiscord(threadId, messageId) {
  return callWorker('/discord-delete', { threadId, messageId });
}
async function deleteWebhookMessage(webhookType, messageId) {
  return callWorker('/webhook-delete', { webhookType, messageId });
}
async function editPviMessage(threadId, messageId, content) {
  return callWorker('/pvi-edit', { threadId, messageId, content });
}

// ── Maintenance ───────────────────────────────────────────────────
async function checkMaintenance(discordId) {
  const uid = discordId || getUserId() || sessionStorage.getItem('maint_uid') || null;
  return callWorker('/api/maintenance', { discordId: uid });
}
async function saveMaintenance(data) {
  return callWorker('/api/maintenance/save', { discordId: getUserId(), data });
}

// ── Secrets (superadmin) ──────────────────────────────────────────
async function getSecrets() {
  return callWorker('/api/secrets/get', { discordId: getUserId() });
}
async function saveSecrets(secrets) {
  return callWorker('/api/secrets/save', { discordId: getUserId(), secrets });
}

// ── Codes pénal/route (superadmin) ────────────────────────────────
async function getCodes() {
  return callWorker('/api/codes/get', { discordId: getUserId() });
}
async function saveCodes(type, articles) {
  return callWorker('/api/codes/save', { discordId: getUserId(), type, articles });
}

// ── Absences (agents) ──────────────────────────────────────────────
async function createAbsence(data) {
  const u = getUser();
  return callWorker('/api/absence/create', { discordId: u?.discordId, agentTag: u?.pseudo, ...data });
}
async function getAbsences() {
  return callWorker('/api/bot/absences', {});
}
async function acknowledgeAbsence(absenceId, ack = true) {
  return callWorker('/api/absence/ack', { discordId: getUserId(), absenceId, ack });
}
async function markPresent(targetId) {
  return callWorker('/api/absence/present', { discordId: getUserId(), targetId });
}
async function deleteAbsence(absenceId) {
  return callWorker('/api/absence/delete', { discordId: getUserId(), absenceId });
}

// ── Modération depuis le site (superadmin uniquement) ──────────────
async function modWarn(targetId, reason) {
  return callWorker('/api/mod/warn', { discordId: getUserId(), targetId, reason });
}
async function modMute(targetId, reason, durationMs) {
  return callWorker('/api/mod/mute', { discordId: getUserId(), targetId, reason, durationMs });
}
async function modUnmute(targetId) {
  return callWorker('/api/mod/unmute', { discordId: getUserId(), targetId });
}
async function modKick(targetId, reason) {
  return callWorker('/api/mod/kick', { discordId: getUserId(), targetId, reason });
}
async function modBan(targetId, reason, deleteMessageDays) {
  return callWorker('/api/mod/ban', { discordId: getUserId(), targetId, reason, deleteMessageDays });
}
async function modSoftban(targetId, reason, deleteMessageDays) {
  return callWorker('/api/mod/softban', { discordId: getUserId(), targetId, reason, deleteMessageDays });
}
async function modUnban(targetId, reason) {
  return callWorker('/api/mod/unban', { discordId: getUserId(), targetId, reason });
}
async function getSanctions(targetId) {
  return callWorker('/api/bot/sanctions', { discordId: getUserId(), targetId });
}

// ── Réveil automatique du bot Discord (hébergé sur Render, plan gratuit) ──
// Le site réveille le bot à l'ouverture puis toutes les 4 minutes,
// pour qu'il soit toujours prêt à poster PVI/FPR/saisies sur Discord.
(function wakeBotLoop() {
  const wake = () => callWorker('/api/bot/wake', {}).catch(() => {});
  wake();
  setInterval(wake, 30 * 1000);
})();

// ── Nom du serveur dynamique (configurable depuis superadmin.html) ────
// Toute page peut utiliser <span data-brand>Police Municipale D'Innovation RP</span>
// ou insérer [[SERVER_NAME]] dans du texte — remplacé automatiquement ici,
// sans jamais avoir besoin de redéployer le code pour un changement de nom.
window.SERVER_NAME = "Police Municipale D'Innovation RP"; // valeur par défaut le temps du chargement
(async function applyBranding() {
  try {
    const r = await fetch(WORKER_URL + '/api/branding');
    const d = await r.json();
    const name = d.serverName || window.SERVER_NAME;
    window.SERVER_NAME = name;

    // Remplacer tous les éléments marqués data-brand
    document.querySelectorAll('[data-brand]').forEach(el => { el.textContent = name; });

    // Remplacer le placeholder [[SERVER_NAME]] dans le titre de l'onglet
    if (document.title.includes('[[SERVER_NAME]]')) {
      document.title = document.title.replace(/\[\[SERVER_NAME\]\]/g, name);
    }

    // Remplacer [[SERVER_NAME]] dans tout le texte visible restant (fallback générique)
    document.querySelectorAll('body *').forEach(el => {
      if (el.children.length === 0 && el.textContent.includes('[[SERVER_NAME]]')) {
        el.textContent = el.textContent.replace(/\[\[SERVER_NAME\]\]/g, name);
      }
    });

    // Remplacer le logo partout (image + favicon) si un logo personnalisé est configuré
    if (d.logoUrl) {
      window.LOGO_URL = d.logoUrl;
      document.querySelectorAll('img[src="logo.png"]').forEach(el => { el.src = d.logoUrl; });
      const favicon = document.querySelector('link[rel="icon"]');
      if (favicon) favicon.href = d.logoUrl;
    }
  } catch (e) { console.warn('applyBranding:', e.message); }
})();

// ── Bouton flottant de bascule thème clair/sombre ─────────────────
(function injectThemeToggle() {
  // Transition douce + corrections mode clair pour les fonds codés en dur
  const styleEl = document.createElement('style');
  styleEl.textContent = `
*{transition:background-color .25s ease,border-color .25s ease,color .25s ease !important}
:root[data-theme="light"] .topbar{background:rgba(255,255,255,.88) !important}
:root[data-theme="light"] body::before{background:radial-gradient(ellipse 70% 50% at 0% 0%,rgba(42,95,255,.07),transparent 60%),radial-gradient(ellipse 60% 40% at 100% 100%,rgba(140,80,255,.05),transparent 60%) !important}
:root[data-theme="light"] .panel-footer{background:rgba(0,0,0,.03) !important}
:root[data-theme="light"] .inf-badge-col{background:rgba(0,0,0,.02) !important}
:root[data-theme="light"] .overlay{background:rgba(0,0,0,.45) !important}
:root[data-theme="light"] .nav-dropdown{background:#ffffff !important;border-color:rgba(20,30,60,.14) !important}
:root[data-theme="light"] .nav-user-chip{background:rgba(20,30,60,.05) !important;border-color:rgba(20,30,60,.12) !important;color:#4a5570 !important}
:root[data-theme="light"] .nav-dd-item{color:#4a5570 !important}
:root[data-theme="light"] .nav-dd-item:hover{background:rgba(20,30,60,.06) !important;color:#0e1424 !important}
:root[data-theme="light"] .nav-btn-x{border-color:rgba(20,30,60,.12) !important;color:#4a5570 !important}
:root[data-theme="light"] .nav-btn-x:hover{background:rgba(20,30,60,.06) !important;color:#0e1424 !important}
:root[data-theme="light"] #theme-toggle-btn{box-shadow:0 4px 16px rgba(20,30,60,.12) !important}
`;
  document.head.appendChild(styleEl);

  const btn = document.createElement('button');
  btn.id = 'theme-toggle-btn';
  btn.setAttribute('aria-label', 'Basculer thème clair/sombre');
  btn.style.cssText = [
    'position:fixed', 'bottom:20px', 'left:20px', 'z-index:9998',
    'width:44px', 'height:44px', 'border-radius:999px',
    'background:var(--s1,var(--surface,#0f1624))',
    'border:1.5px solid var(--b,var(--border,rgba(255,255,255,.1)))',
    'display:flex', 'align-items:center', 'justify-content:center',
    'cursor:pointer', 'font-size:18px', 'box-shadow:0 4px 16px rgba(0,0,0,.25)',
    'transition:transform .2s',
  ].join(';');

  function updateIcon() {
    const theme = document.documentElement.getAttribute('data-theme') || 'dark';
    btn.textContent = theme === 'dark' ? '☀️' : '🌙';
    btn.title = theme === 'dark' ? 'Passer en mode clair' : 'Passer en mode sombre';
  }
  updateIcon();

  btn.addEventListener('click', () => {
    const current = document.documentElement.getAttribute('data-theme') || 'dark';
    const next = current === 'dark' ? 'light' : 'dark';
    document.documentElement.setAttribute('data-theme', next);
    localStorage.setItem('theme', next);
    updateIcon();
  });
  btn.addEventListener('mouseenter', () => { btn.style.transform = 'scale(1.08)'; });
  btn.addEventListener('mouseleave', () => { btn.style.transform = 'none'; });

  if (document.body) {
    document.body.appendChild(btn);
  } else {
    document.addEventListener('DOMContentLoaded', () => document.body.appendChild(btn));
  }
})();

// ── Journal d'activité ──────────────────────────────────────────────
async function logLogin(discordId, tag) {
  return callWorker('/api/log/login', { discordId, tag }).catch(() => {});
}
async function logView(viewType, ref) {
  const u = getUser();
  if (!u) return;
  return callWorker('/api/log/view', { discordId: u.discordId, tag: u.pseudo, viewType, ref }).catch(() => {});
}
async function logDeploy(target, note) {
  return callWorker('/api/log/deploy', { discordId: getUserId(), target, note });
}
async function getActivityLogs(type, limit) {
  return callWorker('/api/logs/get', { discordId: getUserId(), type, limit });
}
