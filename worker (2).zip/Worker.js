// ═══════════════════════════════════════════════════════════════════
//  Cloudflare Worker
//
//  Variables d'env (Settings > Variables) :
//    DEV_ID         — Discord ID du superadmin
//    IMGBB_API_KEY  — clé ImgBB
//    FB_PROJECT     — ID projet Firebase
//    FB_KEY         — clé publique Firebase
//
//  KV Namespace "SECRETS" :
//    bot_token, forum_id, pm_role_id,
//    webhook_pvi, webhook_fpr,
//    webhook_saisies_obj, webhook_saisies_vl
// ═══════════════════════════════════════════════════════════════════

const DISCORD_API = 'https://discord.com/api/v10';
const CORS = {
  'Access-Control-Allow-Origin':  '*',
  'Access-Control-Allow-Methods': 'POST, GET, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization',
  'Access-Control-Max-Age':       '86400',
};

// Détection de démarrage d'isolate — remise à zéro à chaque déploiement du
// Worker (le code redéployé invalide les isolates existants), donc le premier
// log "worker_boot" après un déploiement arrive toujours. Peut aussi se
// déclencher occasionnellement lors d'un recyclage naturel d'isolate par
// Cloudflare hors déploiement (trafic faible) — limite honnête du modèle
// serverless, mais chaque déploiement déclenche bien un log.
let _workerBootLogged = false;

export default {
  async fetch(request, env, ctx) {
    if (request.method === 'OPTIONS')
      return new Response(null, { status: 204, headers: CORS });

    if (!_workerBootLogged) {
      _workerBootLogged = true;
      ctx.waitUntil(logActivity(env, {
        type: 'deploy_worker',
        message: 'Worker démarré (nouvelle isolate — probablement un déploiement)',
      }));
    }

    try {
      return await gatedRoute(request, env);
    } catch (e) {
      return json({ error: e.message || 'Internal error' }, 500);
    }
  }
};

async function route(request, env) {
  const p = new URL(request.url).pathname;
  if (p === '/imgbb')                return await handleImgBB(request, env);
  if (p === '/casier-discord')       return await handleCasierDiscord(request, env);
  if (p === '/discord-delete')       return await handleDiscordDelete(request, env);
  if (p === '/webhook-delete')       return await handleWebhookDelete(request, env);
  if (p === '/pvi-edit')             return await handlePviEdit(request, env);
  if (p === '/api/webhook')          return await handleWebhook(request, env);
  if (p === '/api/maintenance')      return await handleMaintenance(request, env);
  if (p === '/api/check-role')       return await handleCheckRole(request, env);
  if (p === '/api/maintenance/save') return await handleMaintenanceSave(request, env);
  if (p === '/api/secrets/get')      return await handleSecretsGet(request, env);
  if (p === '/api/secrets/save')     return await handleSecretsSave(request, env);
  if (p === '/api/codes/get')        return await handleCodesGet(request, env);
  if (p === '/api/codes/save')       return await handleCodesSave(request, env);
  if (p === '/api/codes/public')     return await handleCodesPublic(request, env);
  if (p === '/api/bot/config')       return await handleBotConfig(request, env);
  if (p === '/api/bot/check-dev')    return await handleBotCheckDev(request, env);
  if (p === '/api/log/login')        return await handleLogLogin(request, env);
  if (p === '/api/log/view')         return await handleLogView(request, env);
  if (p === '/api/log/deploy')       return await handleLogDeploy(request, env);
  if (p === '/api/logs/get')         return await handleLogsGet(request, env);
  if (p === '/api/auth/is-dev')      return await handleAuthIsDev(request, env);
  if (p === '/api/security/list')    return await handleSecurityList(request, env);
  if (p === '/api/security/unban')   return await handleSecurityUnban(request, env);
  if (p === '/api/roles/guild-info') return await handleRolesGuildInfo(request, env);
  if (p === '/api/roles/presets/get')    return await handlePresetsGet(request, env);
  if (p === '/api/roles/presets/save')   return await handlePresetsSave(request, env);
  if (p === '/api/roles/presets/delete') return await handlePresetsDelete(request, env);
  if (p === '/api/roles/apply-preset')   return await handleApplyPreset(request, env);
  if (p === '/api/roles/apply-manual')   return await handleApplyManual(request, env);
  if (p === '/api/bot/update-channel-id') return await handleUpdateChannelId(request, env);
  if (p === '/api/branding')         return await handleBranding(request, env);
  if (p === '/api/bot/wake')         return await handleBotWake(request, env);
  if (p === '/api/bot/sanction')     return await handleBotSanction(request, env);
  if (p === '/api/bot/sanctions')    return await handleBotSanctions(request, env);
  if (p === '/api/bot/absence')      return await handleBotAbsence(request, env);
  if (p === '/api/bot/absences')     return await handleBotAbsences(request, env);
  if (p === '/api/bot/clearwarns')   return await handleBotClearWarns(request, env);
  if (p === '/api/absence/create')   return await handleAbsenceCreate(request, env);
  if (p === '/api/absence/ack')      return await handleAbsenceAck(request, env);
  if (p === '/api/absence/present')  return await handleAbsencePresent(request, env);
  if (p === '/api/absence/delete')   return await handleAbsenceDelete(request, env);
  if (p === '/api/mod/warn')         return await handleModWarn(request, env);
  if (p === '/api/mod/mute')         return await handleModMute(request, env);
  if (p === '/api/mod/unmute')       return await handleModUnmute(request, env);
  if (p === '/api/mod/kick')         return await handleModKick(request, env);
  if (p === '/api/mod/ban')          return await handleModBan(request, env);
  if (p === '/api/mod/softban')      return await handleModSoftban(request, env);
  if (p === '/api/mod/unban')        return await handleModUnban(request, env);
  return json({ error: 'Not found' }, 404);
}

// ── KV helpers ────────────────────────────────────────────────────
const kv = {
  async get(env, k)    { return env.SECRETS ? env.SECRETS.get(k) : null; },
  async set(env, k, v) { if (!env.SECRETS) throw new Error('KV SECRETS non bindé'); return env.SECRETS.put(k, v); },
};
// Récupère bot_api_url sans slash final, pour éviter les doubles slashs dans les URLs construites
async function getBotApiUrl(env) {
  const url = await kv.get(env, 'bot_api_url');
  return url ? url.replace(/\/+$/, '') : null;
}
const mask = v => !v ? '' : v.length <= 8 ? '••••••••' : v.slice(0,4)+'••••••••'+v.slice(-4);

// ── Firestore helpers ─────────────────────────────────────────────
const fbBase = env => `https://firestore.googleapis.com/v1/projects/${env.FB_PROJECT||'lois-innovations-b4293'}/databases/(default)/documents`;
const fbKey  = env => env.FB_KEY || 'AIzaSyABBAUQdMeBqdeGIpzNixApIrUYIyODFd8';

function fsVal(doc, k) {
  if (!doc?.fields?.[k]) return null;
  const v = doc.fields[k];
  return v.stringValue ?? v.booleanValue ?? null;
}
async function fsGet(env, col, id) {
  const r = await fetch(`${fbBase(env)}/${col}/${id}?key=${fbKey(env)}`);
  if (r.status === 404) return null;
  if (!r.ok) throw new Error(`fsGet ${col}/${id}: ${r.status}`);
  return r.json();
}
async function fsPatch(env, col, id, data) {
  const fields = {};
  for (const k in data) {
    const v = data[k];
    if (v === null || v === '')      fields[k] = { nullValue: null };
    else if (typeof v === 'boolean') fields[k] = { booleanValue: v };
    else                              fields[k] = { stringValue: String(v) };
  }
  const m = Object.keys(data).map(k => `updateMask.fieldPaths=${k}`).join('&');
  const r = await fetch(`${fbBase(env)}/${col}/${id}?${m}&key=${fbKey(env)}`, {
    method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ fields }),
  });
  if (!r.ok) throw new Error(`fsPatch ${col}/${id}: ${r.status} ${await r.text()}`);
  return r.json();
}
// Ajoute un document avec ID auto-généré par Firestore
async function fsAdd(env, col, data) {
  const fields = {};
  for (const k in data) {
    const v = data[k];
    if (v === null || v === undefined) fields[k] = { nullValue: null };
    else if (typeof v === 'boolean')   fields[k] = { booleanValue: v };
    else if (typeof v === 'number')    fields[k] = Number.isInteger(v) ? { integerValue: v } : { doubleValue: v };
    else                                 fields[k] = { stringValue: String(v) };
  }
  const r = await fetch(`${fbBase(env)}/${col}?key=${fbKey(env)}`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ fields }),
  });
  if (!r.ok) throw new Error(`fsAdd ${col}: ${r.status} ${await r.text()}`);
  return r.json();
}
// Liste tous les documents d'une collection (paginé automatiquement)
async function fsList(env, col, pageSize = 300) {
  let all = [], nextPageToken = null;
  do {
    const r = await fetch(`${fbBase(env)}/${col}?key=${fbKey(env)}&pageSize=${pageSize}${nextPageToken ? '&pageToken=' + encodeURIComponent(nextPageToken) : ''}`);
    if (!r.ok) throw new Error(`fsList ${col}: ${r.status}`);
    const d = await r.json();
    all = all.concat(d.documents || []);
    nextPageToken = d.nextPageToken || null;
  } while (nextPageToken);
  return all;
}

// ═══════════════════════════════════════════════════════════════
//  SÉCURITÉ — sessions signées, porte d'authentification, bannissement
// ═══════════════════════════════════════════════════════════════
// Principe : le navigateur ne "déclare" jamais son identité. À la connexion, le
// Worker vérifie le token OAuth auprès de Discord puis délivre un jeton signé
// (HMAC-SHA256). Sur chaque requête, l'ID du jeton écrase tout discordId envoyé.
const SESSION_TTL_MS = 24 * 60 * 60 * 1000;
const te = new TextEncoder();
function b64uEncode(bytes) {
  let s = ''; for (const c of new Uint8Array(bytes)) s += String.fromCharCode(c);
  return btoa(s).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}
function b64uDecode(str) {
  str = str.replace(/-/g, '+').replace(/_/g, '/'); while (str.length % 4) str += '=';
  return Uint8Array.from(atob(str), c => c.charCodeAt(0));
}
async function hmacKey(env) {
  const secret = env.SESSION_SECRET || env.WORKER_SECRET;
  if (!secret) return null;
  return crypto.subtle.importKey('raw', te.encode('session:' + secret), { name: 'HMAC', hash: 'SHA-256' }, false, ['sign', 'verify']);
}
async function signSession(env, claims) {
  const key = await hmacKey(env);
  if (!key) throw new Error('WORKER_SECRET (ou SESSION_SECRET) manquant : impossible de créer une session');
  const payload = b64uEncode(te.encode(JSON.stringify(claims)));
  const sig = b64uEncode(await crypto.subtle.sign('HMAC', key, te.encode(payload)));
  return payload + '.' + sig;
}
async function verifySession(env, token) {
  try {
    if (!token) return null;
    const [payload, sig] = token.split('.');
    if (!payload || !sig) return null;
    const key = await hmacKey(env);
    if (!key) return null;
    if (!(await crypto.subtle.verify('HMAC', key, b64uDecode(sig), te.encode(payload)))) return null;
    const c = JSON.parse(new TextDecoder().decode(b64uDecode(payload)));
    if (!c.id || !c.exp || c.exp < Date.now()) return null;
    return c;
  } catch (e) { return null; }
}

// Bannissements (Firestore banned_users/{id}) — cache 30 s par isolate
const _banCache = new Map();
async function isBanned(env, id) {
  const hit = _banCache.get(id);
  if (hit && Date.now() - hit.t < 30000) return hit.v;
  let v = false;
  try { v = !!(await fsGet(env, 'banned_users', id)); } catch (e) { v = false; }
  _banCache.set(id, { v, t: Date.now() });
  return v;
}
function dayKey() {
  try { return new Date().toLocaleDateString('en-CA', { timeZone: 'Europe/Paris' }); }
  catch (e) { return new Date().toISOString().slice(0, 10); }
}
const MAX_DENIED_PER_DAY = 3;

// Alerte privée au dev (message Discord direct -> notification sur ton téléphone via l'appli Discord)
async function alertDev(env, text) {
  try {
    const botToken = await kv.get(env, 'bot_token');
    if (!botToken || !env.DEV_ID) return;
    const ch = await dFetch('users/@me/channels', 'POST', { recipient_id: env.DEV_ID }, botToken);
    if (!ch.ok) return;
    const c = await ch.json();
    await dFetch(`channels/${c.id}/messages`, 'POST', {
      embeds: [{ title: '🚨 Alerte sécurité', description: text, color: 0xff4d6d, timestamp: new Date().toISOString() }],
    }, botToken);
  } catch (e) { console.warn('alertDev:', e.message); }
}

// Enregistre un accès refusé (identité VÉRIFIÉE uniquement) ; bannit à la 3e tentative du jour
async function recordDenied(env, request, sess, path) {
  const key = `${sess.id}_${dayKey()}`;
  let count = 0;
  try {
    const doc = await fsGet(env, 'security_attempts', key);
    if (doc) count = parseInt(fsVal(doc, 'count') || '0') || 0;
  } catch (e) {}
  count++;
  const ip = getClientIP(request);
  try { await fsPatch(env, 'security_attempts', key, { count: String(count), userId: sess.id, userTag: sess.u || '', ip, lastPath: path, lastAt: new Date().toISOString() }); } catch (e) {}

  const who = `${sess.u || sess.id} (${sess.id})`;
  await logActivity(env, {
    type: 'security',
    message: `Accès refusé ${count}/${MAX_DENIED_PER_DAY} : ${who} a tenté d'atteindre ${path}`,
    actorId: sess.id, actorTag: sess.u || '', ip, meta: { path, count },
  });

  if (count >= MAX_DENIED_PER_DAY) {
    try {
      await fsPatch(env, 'banned_users', sess.id, {
        userId: sess.id, userTag: sess.u || '', ip, bannedAt: new Date().toISOString(),
        reason: `${count} tentatives d'accès non autorisé dans la journée (dernière : ${path})`,
      });
    } catch (e) {}
    _banCache.set(sess.id, { v: true, t: Date.now() });
    await logActivity(env, { type: 'security', message: `🚫 ${who} BANNI définitivement (${count} accès non autorisés)`, actorId: sess.id, actorTag: sess.u || '', ip });
    await alertDev(env, `**${who}** a été **banni définitivement** du site après ${count} tentatives d'accès non autorisé aujourd'hui.\nDernière cible : \`${path}\`\nIP : \`${ip}\`\n\nTu peux le débannir depuis *Logs techniques → Utilisateurs bannis*.`);
    return { count, banned: true };
  }
  return { count, banned: false };
}

// Catégories de routes
const PUBLIC_PATHS = new Set(['/api/branding', '/api/codes/public', '/api/bot/wake', '/api/maintenance', '/api/check-role']);
const AGENT_PATHS  = new Set(['/imgbb', '/casier-discord', '/discord-delete', '/webhook-delete', '/pvi-edit', '/api/webhook', '/api/absence/create']);
const DEV_EXACT    = new Set(['/api/maintenance/save', '/api/secrets/get', '/api/secrets/save', '/api/codes/get', '/api/codes/save',
                              '/api/logs/get', '/api/log/deploy', '/api/auth/is-dev', '/api/security/list', '/api/security/unban']);
const isDevPath = p => DEV_EXACT.has(p) || p.startsWith('/api/mod/') || p.startsWith('/api/roles/');

// Porte d'authentification : appelée pour TOUTES les requêtes avant les handlers
async function gatedRoute(request, env) {
  const p = new URL(request.url).pathname;
  let body = {};
  if (request.method === 'POST') {
    try { const b = await request.json(); if (b && typeof b === 'object' && !Array.isArray(b)) body = b; } catch (e) {}
  }
  const rebuild = b => new Request(request.url, {
    method: request.method, headers: request.headers,
    body: request.method === 'POST' ? JSON.stringify(b) : undefined,
  });

  // Le bot s'authentifie avec le secret partagé : son contenu est de confiance (identités fournies par Discord)
  if (isBotAuthed(env, body.secret)) return route(rebuild(body), env);

  const auth = request.headers.get('Authorization') || '';
  const sess = auth.startsWith('Bearer ') ? await verifySession(env, auth.slice(7)) : null;

  if (sess && sess.id !== env.DEV_ID && await isBanned(env, sess.id)) {
    return json({ error: 'Accès définitivement refusé', banned: true }, 403);
  }

  // L'identité vient UNIQUEMENT du jeton signé — jamais du corps de la requête
  if (sess) body.discordId = sess.id; else delete body.discordId;

  if (PUBLIC_PATHS.has(p)) return route(rebuild(body), env);

  if (!sess) {
    console.warn(`[sécurité] requête sans session valide vers ${p} depuis ${getClientIP(request)}`);
    return json({ error: 'Session invalide ou expirée — reconnectez-vous', code: 'no_session' }, 401);
  }

  if (isDevPath(p) && sess.id !== env.DEV_ID) {
    const r = await recordDenied(env, request, sess, p);
    return json({ error: r.banned ? 'Accès définitivement refusé' : 'Accès refusé', denied: true, banned: r.banned, attempts: r.count }, 403);
  }

  if (AGENT_PATHS.has(p) && !(sess.ag || sess.id === env.DEV_ID)) {
    return json({ error: 'Réservé aux agents' }, 403);
  }

  return route(rebuild(body), env);
}

// ── /api/auth/is-dev — garde des pages superadmin (la porte a déjà refusé les non-dev) ──
async function handleAuthIsDev(request, env) {
  return json({ isDev: true });
}

// ── /api/security/list — bannis + tentatives récentes (dev) ──
async function handleSecurityList(request, env) {
  const [bans, atts] = await Promise.all([fsList(env, 'banned_users', 200), fsList(env, 'security_attempts', 300)]);
  const conv = d => { const o = { _id: d.name.split('/').pop() }; for (const k in (d.fields || {})) o[k] = fsToJs(d.fields[k]); return o; };
  const banned = bans.map(conv).sort((a, b) => new Date(b.bannedAt) - new Date(a.bannedAt));
  const attempts = atts.map(conv).sort((a, b) => new Date(b.lastAt) - new Date(a.lastAt)).slice(0, 50);
  return json({ banned, attempts });
}

// ── /api/security/unban — lève un bannissement et remet le compteur à zéro (dev) ──
async function handleSecurityUnban(request, env) {
  const { userId } = await request.json().catch(() => ({}));
  if (!userId || !/^\d{17,19}$/.test(userId)) return json({ error: 'userId invalide' }, 400);
  await fsDelete(env, 'banned_users', userId);
  await fsDelete(env, 'security_attempts', `${userId}_${dayKey()}`);
  _banCache.set(userId, { v: false, t: Date.now() });
  await logActivity(env, { type: 'security', message: `Utilisateur ${userId} débanni`, actorId: env.DEV_ID, ip: getClientIP(request) });
  return json({ unbanned: true });
}

// Supprime un document par son ID
async function fsDelete(env, col, id) {
  await fetch(`${fbBase(env)}/${col}/${id}?key=${fbKey(env)}`, { method: 'DELETE' });
}

// ═══════════════════════════════════════════════════════════════
//  JOURNAL D'ACTIVITÉ — connexions, actions, déploiements
// ═══════════════════════════════════════════════════════════════
function getClientIP(request) {
  return request.headers.get('CF-Connecting-IP') || request.headers.get('X-Forwarded-For') || 'inconnue';
}

async function logActivity(env, { type, message, actorId, actorTag, ip, meta }) {
  try {
    await fsAdd(env, 'activity_log', {
      type: type || 'unknown',
      message: message || '',
      actorId: actorId || '',
      actorTag: actorTag || '',
      ip: ip || '',
      meta: meta ? JSON.stringify(meta) : '',
      timestamp: new Date().toISOString(),
    });
  } catch (e) { console.warn('logActivity:', e.message); }
}

// ── Auth check ────────────────────────────────────────────────────
const isDev = (env, id) => !!id && id === env.DEV_ID;
// Vérifie si l'utilisateur est superadmin (DEV_ID) OU a le rôle admin (Firestore users/{id})
async function isAdminOrDev(env, id) {
  if (isDev(env, id)) return true;
  if (!id) return false;
  try {
    const doc = await fsGet(env, 'users', id);
    if (!doc) return false;
    const role = fsToJs(doc.fields?.role || { nullValue: null });
    return role === 'admin';
  } catch (e) {
    return false;
  }
}

// ── /imgbb ────────────────────────────────────────────────────────
async function handleImgBB(request, env) {
  const { image, name } = await request.json();
  if (!image) return json({ error: 'No image' }, 400);
  const form = new FormData();
  form.append('image', image.replace(/^data:image\/\w+;base64,/, ''));
  if (name) form.append('name', name);
  const key = env.IMGBB_API_KEY || '';
  const res  = await fetch(`https://api.imgbb.com/1/upload?key=${key}`, { method: 'POST', body: form });
  const data = await res.json();
  if (!data.success) return json({ error: data.error?.message || 'ImgBB error' }, 500);
  return json({ url: data.data.url, thumb: data.data.thumb?.url || data.data.url, delete_url: data.data.delete_url });
}

// ── /api/webhook — envoie un webhook depuis KV ───────────────────
async function handleWebhook(request, env) {
  const { type, embeds, content, image, danger, discordId, actorTag } = await request.json();
  const keyMap = { pvi:'channel_pvi_id', fpr:'channel_fpr_id', saisies_obj:'channel_saisies_obj_id', saisies_vl:'channel_saisies_vl_id' };
  const kvKey = keyMap[type];
  if (!kvKey) return json({ error: 'type invalide' }, 400);

  const [channelId, botApiUrlRaw] = await Promise.all([kv.get(env, kvKey), getBotApiUrl(env)]);
  if (!channelId)  return json({ error: `Salon "${type}" non configuré dans KV` }, 404);
  if (!botApiUrlRaw)  return json({ error: 'bot_api_url non configuré (URL du bot Render)' }, 404);
  const botApiUrl = botApiUrlRaw.replace(/\/+$/, '');

  let finalContent = content || '';
  if (danger) {
    const roleId = await kv.get(env, 'pm_role_id');
    if (roleId) finalContent = `<@&${roleId}> ${finalContent || '🚨 **SUSPECT DANGEREUX**'}`;
  }

  const res = await fetch(`${botApiUrl}/api/send`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ secret: env.WORKER_SECRET, channelId, embeds, content: finalContent || undefined, image }),
  });
  if (!res.ok) return json({ error: `Bot indisponible (${res.status}): ${await res.text()}` }, 502);
  const d = await res.json();
  if (d.error) return json({ error: d.error }, 500);

  const TYPE_LABEL = { pvi: 'PVI', fpr: 'FPR', saisies_obj: 'Saisie (objet)', saisies_vl: 'Saisie (véhicule)' };
  await logActivity(env, {
    type: type.startsWith('saisies') ? 'saisie' : type,
    message: `${TYPE_LABEL[type] || type} envoyé sur Discord par ${actorTag || discordId || 'inconnu'}`,
    actorId: discordId || '', actorTag: actorTag || '',
    ip: getClientIP(request),
  });

  return json({ sent: true, messageId: d.messageId || null });
}

// ── /casier-discord ───────────────────────────────────────────────
async function handleCasierDiscord(request, env) {
  const { suspectRP, threadId, content, threadTitle } = await request.json();
  const [forumId, botToken] = await Promise.all([kv.get(env,'forum_id'), kv.get(env,'bot_token')]);
  if (!forumId)  return json({ error: 'forum_id non configuré' }, 404);
  if (!botToken) return json({ error: 'bot_token non configuré' }, 404);

  if (!threadId) {
    const res = await dFetch(`channels/${forumId}/threads`, 'POST',
      { name: threadTitle || `📋 Casier — ${suspectRP}`, message: { content }, auto_archive_duration: 10080 }, botToken);
    if (!res.ok) return json({ error: `Thread: ${await res.text()}` }, 500);
    const d = await res.json();
    return json({ threadId: d.id, messageId: d.message?.id || null, created: true });
  } else {
    const res = await dFetch(`channels/${threadId}/messages`, 'POST', { content }, botToken);
    if (!res.ok) return json({ error: `Message: ${await res.text()}` }, 500);
    const d = await res.json();
    return json({ threadId, messageId: d.id, created: false });
  }
}

// ── /discord-delete ───────────────────────────────────────────────
async function handleDiscordDelete(request, env) {
  const { threadId, messageId } = await request.json();
  if (!threadId) return json({ error: 'threadId required' }, 400);
  const botToken = await kv.get(env, 'bot_token');
  if (!botToken) return json({ error: 'bot_token non configuré' }, 404);
  const ep = messageId ? `channels/${threadId}/messages/${messageId}` : `channels/${threadId}`;
  const res = await dFetch(ep, 'DELETE', null, botToken);
  if (!res.ok) return json({ error: `Delete: ${await res.text()}` }, 500);
  return json({ deleted: messageId ? 'message' : 'thread' });
}

// ── /webhook-delete ───────────────────────────────────────────────
async function handleWebhookDelete(request, env) {
  const { webhookType, messageId } = await request.json();
  if (!webhookType || !messageId) return json({ error: 'webhookType et messageId requis' }, 400);
  const map = { pvi:'channel_pvi_id', fpr:'channel_fpr_id', saisies_obj:'channel_saisies_obj_id', saisies_vl:'channel_saisies_vl_id' };
  const kvKey = map[webhookType] || webhookType;

  const [channelId, botApiUrlRaw] = await Promise.all([kv.get(env, kvKey), getBotApiUrl(env)]);
  if (!channelId) return json({ error: 'Salon non configuré' }, 404);
  if (!botApiUrlRaw) return json({ error: 'bot_api_url non configuré' }, 404);
  const botApiUrl = botApiUrlRaw.replace(/\/+$/, '');

  const res = await fetch(`${botApiUrl}/api/delete`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ secret: env.WORKER_SECRET, channelId, messageId }),
  });
  if (!res.ok && res.status !== 404) return json({ error: `Bot delete: ${res.status}` }, 500);
  return json({ deleted: true });
}

// ── /pvi-edit ─────────────────────────────────────────────────────
async function handlePviEdit(request, env) {
  const { threadId, messageId, content } = await request.json();
  if (!threadId || !messageId || !content) return json({ error: 'Paramètres manquants' }, 400);
  const botToken = await kv.get(env, 'bot_token');
  if (!botToken) return json({ error: 'bot_token non configuré' }, 404);
  const res = await dFetch(`channels/${threadId}/messages/${messageId}`, 'PATCH', { content }, botToken);
  if (!res.ok) return json({ error: `Edit: ${await res.text()}` }, 500);
  const d = await res.json();
  return json({ edited: true, messageId: d.id });
}

// ── /api/maintenance ─────────────────────────────────────────────
// ── /api/check-role ───────────────────────────────────────────────
// Vérifie si l'utilisateur a le rôle PM sur le serveur, sans exposer
// GUILD_ID ni PM_ROLE_ID côté client. Ces deux valeurs vivent dans KV.
// ── Auth bot : vérifie le secret partagé (WORKER_SECRET) ──────────
const isBotAuthed = (env, secret) => !!secret && !!env.WORKER_SECRET && secret === env.WORKER_SECRET;

// ── /api/bot/config — le bot lit sa config (IDs) depuis KV ────────
async function handleBotConfig(request, env) {
  const { secret } = await request.json().catch(() => ({}));
  if (!isBotAuthed(env, secret)) return json({ error: 'Non autorisé' }, 403);
  const keys = ['guild_id', 'pm_role_id', 'forum_absences_id', 'mod_log_channel_id', 'panel_channel_id', 'server_name'];
  const cfg = {};
  for (const k of keys) cfg[k] = await kv.get(env, k);
  if (!cfg.server_name) cfg.server_name = "Police";
  return json(cfg);
}

// ── /api/bot/check-dev — vérifie si un Discord ID est le DEV_ID ───
// N'expose jamais la valeur du DEV_ID lui-même, uniquement true/false.
async function handleBotCheckDev(request, env) {
  const { secret, discordId } = await request.json().catch(() => ({}));
  if (!isBotAuthed(env, secret)) return json({ error: 'Non autorisé' }, 403);
  return json({ isDev: isDev(env, discordId) });
}

// ── /api/log/login — appelé par callback.html après une connexion réussie ──
async function handleLogLogin(request, env) {
  const { discordId, tag } = await request.json().catch(() => ({}));
  if (!discordId || !/^\d{17,19}$/.test(discordId)) return json({ error: 'discordId invalide' }, 400);
  await logActivity(env, {
    type: 'login',
    message: `Connexion de ${tag || discordId}`,
    actorId: discordId, actorTag: tag || '',
    ip: getClientIP(request),
  });
  return json({ logged: true });
}

// ── /api/log/view — événement léger (ex: lecture d'un PVI) ────────
const VIEW_TYPES = new Set(['pvi', 'fpr', 'casier', 'saisie']);
async function handleLogView(request, env) {
  const { discordId, tag, viewType, ref } = await request.json().catch(() => ({}));
  if (!discordId || !/^\d{17,19}$/.test(discordId)) return json({ error: 'discordId invalide' }, 400);
  if (!VIEW_TYPES.has(viewType)) return json({ error: 'viewType invalide' }, 400);
  await logActivity(env, {
    type: 'view',
    message: `${tag || discordId} a consulté ${viewType}${ref ? ' ' + ref : ''}`,
    actorId: discordId, actorTag: tag || '',
    ip: getClientIP(request),
    meta: { viewType, ref },
  });
  return json({ logged: true });
}

// ── /api/log/deploy — marquage manuel (Worker/site) ou auto (bot) ──
async function handleLogDeploy(request, env) {
  const { discordId, secret, target, note } = await request.json().catch(() => ({}));
  const authedAsBot = isBotAuthed(env, secret);
  if (!authedAsBot && !isDev(env, discordId)) return json({ error: 'Non autorisé' }, 403);
  if (!['worker', 'bot', 'site'].includes(target)) return json({ error: 'target invalide' }, 400);

  await logActivity(env, {
    type: `deploy_${target}`,
    message: note || `Déploiement marqué : ${target}`,
    actorId: discordId || '', actorTag: authedAsBot ? 'bot' : '',
    ip: authedAsBot ? '' : getClientIP(request),
  });
  return json({ logged: true });
}

// ── /api/logs/get — récupère le journal, réservé au DEV_ID ────────
async function handleLogsGet(request, env) {
  const { discordId, type, limit } = await request.json().catch(() => ({}));
  if (!isDev(env, discordId)) return json({ error: 'Non autorisé' }, 403);

  try {
    const docs = await fsList(env, 'activity_log', 500);
    let all = docs.map(d => {
      const o = { _id: d.name.split('/').pop() };
      for (const k in (d.fields || {})) o[k] = fsToJs(d.fields[k]);
      if (o.meta) { try { o.meta = JSON.parse(o.meta); } catch (e) {} }
      return o;
    });
    all.sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));
    if (type) all = all.filter(e => e.type === type);
    const max = Math.min(limit || 200, 500);
    return json({ logs: all.slice(0, max), total: all.length });
  } catch (e) {
    return json({ logs: [], error: e.message });
  }
}

// ── /api/bot/update-channel-id — met à jour automatiquement les ──
// références KV d'un salon quand il est supprimé puis recréé (son ID
// change côté Discord), pour ne jamais casser la config existante.
async function handleUpdateChannelId(request, env) {
  const { secret, oldId, newId } = await request.json().catch(() => ({}));
  if (!isBotAuthed(env, secret)) return json({ error: 'Non autorisé' }, 403);
  if (!oldId || !newId) return json({ error: 'oldId et newId requis' }, 400);

  const channelKeys = ['forum_id','channel_pvi_id','channel_fpr_id','channel_saisies_obj_id','channel_saisies_vl_id','forum_absences_id','mod_log_channel_id','panel_channel_id'];
  const updated = [];
  for (const k of channelKeys) {
    const val = await kv.get(env, k);
    if (val === oldId) {
      await kv.set(env, k, newId);
      updated.push(k);
    }
  }
  return json({ updated });
}

// ── /api/branding — lecture publique, aucune auth requise ─────────
// Utilisé par toutes les pages du site pour afficher le nom du serveur
// dynamiquement, sans jamais avoir à redéployer le code.
async function handleBranding(request, env) {
  const [name, logoUrl] = await Promise.all([kv.get(env, 'server_name'), kv.get(env, 'logo_url')]);
  return json({ serverName: name || "Police", logoUrl: logoUrl || null });
}
// Helper interne — récupère le nom du serveur pour l'insérer dans les messages Discord
async function getServerName(env) {
  const name = await kv.get(env, 'server_name');
  return name || "Police";
}

// ── /api/bot/wake — appelé périodiquement par le client pour empêcher ──
// le bot Render (plan gratuit) de se mettre en veille. L'URL du bot n'est
// jamais exposée au navigateur — le Worker fait proxy.
async function handleBotWake(request, env) {
  try {
    const botApiUrl = await getBotApiUrl(env);
    if (!botApiUrl) return json({ awake: false, error: 'bot_api_url non configuré' });
    const res = await fetch(`${botApiUrl}/ping`, { method: 'GET' });
    return json({ awake: res.ok });
  } catch (e) {
    return json({ awake: false, error: e.message });
  }
}

// ── /api/bot/sanction — le bot sauvegarde une sanction ────────────
async function handleBotSanction(request, env) {
  const body = await request.json().catch(() => ({}));
  if (!isBotAuthed(env, body.secret)) return json({ error: 'Non autorisé' }, 403);
  const { type, targetId, targetTag, moderatorId, moderatorTag, reason, duration, timestamp } = body;
  if (!type || !targetId) return json({ error: 'Paramètres manquants' }, 400);
  await fsAdd(env, 'sanctions', {
    type, targetId, targetTag: targetTag || '', moderatorId: moderatorId || '',
    moderatorTag: moderatorTag || '', reason: reason || '', duration: duration || '',
    timestamp: timestamp || new Date().toISOString(),
  });
  return json({ saved: true });
}

// ── /api/bot/sanctions — récupère l'historique d'un membre ────────
async function handleBotSanctions(request, env) {
  const body = await request.json().catch(() => ({}));
  const { targetId, secret, discordId } = body;
  // Autorisé pour le bot (secret) OU pour un membre consultant ses propres sanctions via le site
  if (!isBotAuthed(env, secret) && !isDev(env, discordId) && discordId !== targetId) {
    return json({ error: 'Non autorisé' }, 403);
  }
  if (!targetId) return json({ error: 'targetId requis' }, 400);
  try {
    const docs = await fsList(env, 'sanctions', 300);
    const all = docs.map(d => {
      const o = {};
      for (const k in (d.fields || {})) o[k] = fsToJs(d.fields[k]);
      return o;
    });
    const filtered = all.filter(s => s.targetId === targetId).sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));
    return json({ sanctions: filtered });
  } catch (e) {
    return json({ sanctions: [], error: e.message });
  }
}

// ── /api/bot/absence — le bot sauvegarde une déclaration d'absence ──
async function handleBotAbsence(request, env) {
  const body = await request.json().catch(() => ({}));
  if (!isBotAuthed(env, body.secret)) return json({ error: 'Non autorisé' }, 403);
  const { agentId, agentTag, debut, fin, type, raison, threadId, createdAt } = body;
  if (!agentId || !debut || !fin) return json({ error: 'Paramètres manquants' }, 400);
  await fsAdd(env, 'absences', {
    agentId, agentTag: agentTag || '', debut, fin, type: type || '',
    raison: raison || '', threadId: threadId || '', createdAt: createdAt || new Date().toISOString(),
  });
  return json({ saved: true });
}

// ── /api/bot/absences — liste les absences (pour affichage sur le site) ──
async function handleBotAbsences(request, env) {
  try {
    const docs = await fsList(env, 'absences', 300);
    const all = docs.map(d => {
      const o = { _id: d.name.split('/').pop() };
      for (const k in (d.fields || {})) o[k] = fsToJs(d.fields[k]);
      return o;
    });
    all.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
    return json({ absences: all });
  } catch (e) {
    return json({ absences: [], error: e.message });
  }
}

// ── /api/bot/clearwarns — supprime tous les warns d'un membre ─────
// Appelable par le bot (secret) OU par un admin/superadmin depuis le site.
async function handleBotClearWarns(request, env) {
  const body = await request.json().catch(() => ({}));
  const { targetId, secret, discordId } = body;
  const authedAsBot = isBotAuthed(env, secret);
  const authedAsAdmin = !authedAsBot && (await isAdminOrDev(env, discordId));
  if (!authedAsBot && !authedAsAdmin) return json({ error: 'Non autorisé' }, 403);
  if (!targetId) return json({ error: 'targetId requis' }, 400);

  try {
    const docs = await fsList(env, 'sanctions', 300);
    let count = 0;
    for (const d of docs) {
      const o = {};
      for (const k in (d.fields || {})) o[k] = fsToJs(d.fields[k]);
      if (o.targetId === targetId && o.type === 'warn') {
        const id = d.name.split('/').pop();
        await fsDelete(env, 'sanctions', id);
        count++;
      }
    }
    if (count > 0) {
      await logActivity(env, {
        type: 'sanction',
        message: `${count} avertissement(s) supprimé(s) pour ${targetId} par ${authedAsBot ? 'bot' : discordId}`,
        actorId: authedAsBot ? '' : (discordId || ''), actorTag: authedAsBot ? 'bot' : '',
        meta: { sanctionType: 'clearwarns', targetId, count },
      });
    }
    return json({ success: true, count });
  } catch (e) {
    return json({ error: e.message }, 500);
  }
}

// ── /api/absence/create — un agent déclare son absence depuis le site ──
// Crée directement le thread Discord (pas besoin que le bot soit en ligne)
// ── Assure l'existence du rôle "Absent" sur le serveur, le crée si besoin ──
async function ensureAbsentRole(env, guildId, botToken) {
  let roleId = await kv.get(env, 'absent_role_id');
  if (roleId) {
    // Vérifier qu'il existe toujours
    const check = await dFetch(`guilds/${guildId}/roles`, 'GET', null, botToken);
    if (check.ok) {
      const roles = await check.json();
      if (roles.some(r => r.id === roleId)) return roleId;
    }
    roleId = null;
  }
  // Créer le rôle
  const res = await dFetch(`guilds/${guildId}/roles`, 'POST', {
    name: '🟠 Absent', color: 0xff9f43, hoist: true, mentionable: false,
  }, botToken);
  if (!res.ok) throw new Error(`Création rôle Absent: ${await res.text()}`);
  const role = await res.json();
  await kv.set(env, 'absent_role_id', role.id);
  return role.id;
}

// ── Assure l'existence des tags "Absent"/"Présent" sur le forum ────────
async function ensureForumTags(env, forumId, botToken) {
  let absentTagId  = await kv.get(env, 'tag_absent_id');
  let presentTagId = await kv.get(env, 'tag_present_id');
  if (absentTagId && presentTagId) return { absentTagId, presentTagId };

  const chRes = await dFetch(`channels/${forumId}`, 'GET', null, botToken);
  if (!chRes.ok) return { absentTagId: null, presentTagId: null };
  const channel = await chRes.json();
  const existingTags = channel.available_tags || [];

  let found = existingTags.find(t => t.name === '🟠 Absent');
  let foundPresent = existingTags.find(t => t.name === '🟢 Présent');
  const newTags = [...existingTags];
  let changed = false;

  if (!found) {
    newTags.push({ name: '🟠 Absent', moderated: false });
    changed = true;
  }
  if (!foundPresent) {
    newTags.push({ name: '🟢 Présent', moderated: false });
    changed = true;
  }

  if (changed) {
    const patchRes = await dFetch(`channels/${forumId}`, 'PATCH', { available_tags: newTags }, botToken);
    if (patchRes.ok) {
      const updated = await patchRes.json();
      found        = (updated.available_tags || []).find(t => t.name === '🟠 Absent');
      foundPresent = (updated.available_tags || []).find(t => t.name === '🟢 Présent');
    }
  }

  absentTagId  = found?.id || null;
  presentTagId = foundPresent?.id || null;
  if (absentTagId)  await kv.set(env, 'tag_absent_id', absentTagId);
  if (presentTagId) await kv.set(env, 'tag_present_id', presentTagId);
  return { absentTagId, presentTagId };
}

async function handleAbsenceCreate(request, env) {
  try {
    const body = await request.json().catch(() => ({}));
    const { discordId, debut, fin, type, raison } = body;
    if (!discordId) return json({ error: 'Non authentifié' }, 401);
    if (!/^\d{17,19}$/.test(discordId)) return json({ error: 'ID invalide' }, 401);
    if (!debut || !fin) return json({ error: 'Dates de début et fin requises' }, 400);

    const [forumId, botToken, guildId] = await Promise.all([
      kv.get(env, 'forum_absences_id'), kv.get(env, 'bot_token'), kv.get(env, 'guild_id'),
    ]);
    if (!forumId)  return json({ error: 'Le forum des absences n\'est pas configuré (superadmin → Bot Discord)' }, 404);
    if (!botToken) return json({ error: 'bot_token non configuré (superadmin → Secrets)' }, 404);

    // Pseudo RP (jamais le pseudo Discord)
    let pseudoRP = discordId;
    try {
      const userDoc = await fsGet(env, 'users', discordId);
      if (userDoc) {
        const u = {};
        for (const k in (userDoc.fields || {})) u[k] = fsToJs(userDoc.fields[k]);
        pseudoRP = u.pseudo || u.pseudoRP || u.name || discordId;
      }
    } catch (e) { /* fallback */ }

    // Rôle Absent — créé automatiquement si besoin, puis assigné
    if (guildId) {
      try {
        const roleId = await ensureAbsentRole(env, guildId, botToken);
        await dFetch(`guilds/${guildId}/members/${discordId}/roles/${roleId}`, 'PUT', null, botToken);
      } catch (e) { console.warn('Rôle Absent:', e.message); }
    }

    // Tags forum Absent/Présent
    const { absentTagId } = await ensureForumTags(env, forumId, botToken).catch(() => ({ absentTagId: null }));
    const serverName = await getServerName(env);

    const embed = {
      title: '📅 Déclaration d\'absence',
      color: 0x4d9fff,
      fields: [
        { name: '👤 Agent', value: `${pseudoRP} (<@${discordId}>)`, inline: true },
        { name: '🏷️ Type', value: type || 'Non précisé', inline: true },
        { name: '🕐 Début', value: debut, inline: true },
        { name: '🕐 Fin', value: fin, inline: true },
        { name: '📝 Raison', value: raison || 'Non précisé' },
      ],
      footer: { text: `${serverName} — déclarée depuis le site` },
      timestamp: new Date().toISOString(),
    };

    // Chercher si un thread existe déjà pour cet agent — un seul post par personne
    let existingThreadId = null;
    try {
      const docs = await fsList(env, 'absences', 300);
      for (const d of docs) {
        const o = {};
        for (const k in (d.fields || {})) o[k] = fsToJs(d.fields[k]);
        if (o.agentId === discordId && o.threadId) { existingThreadId = o.threadId; break; }
      }
    } catch (e) { /* non bloquant */ }

    let threadId = existingThreadId;
    let messageId = null;

    if (existingThreadId) {
      const checkRes = await dFetch(`channels/${existingThreadId}`, 'GET', null, botToken);
      if (checkRes.ok) {
        const msgRes = await dFetch(`channels/${existingThreadId}/messages`, 'POST', { embeds: [embed] }, botToken);
        if (!msgRes.ok) return json({ error: `Discord (message): ${await msgRes.text()}` }, 500);
        const msgData = await msgRes.json();
        messageId = msgData.id;
        // Remettre le tag "Absent" sur le thread existant
        if (absentTagId) {
          await dFetch(`channels/${existingThreadId}`, 'PATCH', { applied_tags: [absentTagId] }, botToken).catch(() => {});
        }
      } else {
        threadId = null; // thread supprimé côté Discord — on en recrée un
      }
    }

    if (!threadId) {
      const res = await dFetch(`channels/${forumId}/threads`, 'POST', {
        name: `📅 ${pseudoRP}`,
        message: { embeds: [embed] },
        auto_archive_duration: 10080,
        applied_tags: absentTagId ? [absentTagId] : undefined,
      }, botToken);
      if (!res.ok) return json({ error: `Discord (thread): ${await res.text()}` }, 500);
      const d = await res.json();
      threadId = d.id;
      messageId = d.message?.id || null;
    }

    let absenceId = null;
    try {
      const added = await fsAdd(env, 'absences', {
        agentId: discordId, agentTag: pseudoRP, debut, fin, type: type || '',
        raison: raison || '', threadId, messageId: messageId || '', createdAt: new Date().toISOString(),
      });
      absenceId = added.name?.split('/').pop() || null;
    } catch (e) { /* non bloquant */ }

    await logActivity(env, {
      type: 'absence',
      message: `Absence déclarée par ${pseudoRP} (${debut} → ${fin})`,
      actorId: discordId, actorTag: pseudoRP,
      ip: getClientIP(request),
    });

    return json({ created: true, threadId, absenceId });
  } catch (e) {
    return json({ error: 'Erreur interne: ' + e.message }, 500);
  }
}

// ── /api/absence/ack — marque une absence comme prise en compte ───
// Accessible aux admins (rôle Firestore 'admin') ET au superadmin, pas
// réservé au seul DEV_ID.
async function handleAbsenceAck(request, env) {
  const { discordId, absenceId, ack } = await request.json().catch(() => ({}));
  if (!(await isAdminOrDev(env, discordId))) return json({ error: 'Non autorisé — rôle admin requis' }, 403);
  if (!absenceId) return json({ error: 'absenceId requis' }, 400);

  try {
    await fsPatch(env, 'absences', absenceId, {
      acknowledged: ack !== false,
      acknowledgedBy: discordId,
      acknowledgedAt: new Date().toISOString(),
    });
    return json({ success: true });
  } catch (e) {
    return json({ error: e.message }, 500);
  }
}

// ── /api/absence/present — marque un agent comme de retour (présent) ──
// Retire le rôle Absent, bascule le tag du thread sur "Présent".
// Accessible à l'agent lui-même OU à un admin/superadmin.
async function handleAbsencePresent(request, env) {
  const { discordId, targetId } = await request.json().catch(() => ({}));
  const target = targetId || discordId;
  if (!discordId || !target) return json({ error: 'Paramètres manquants' }, 400);
  if (target !== discordId && !(await isAdminOrDev(env, discordId))) {
    return json({ error: 'Non autorisé' }, 403);
  }

  const [guildId, botToken, presentTagId] = await Promise.all([
    kv.get(env, 'guild_id'), kv.get(env, 'bot_token'), kv.get(env, 'tag_present_id'),
  ]);

  // Retirer le rôle Absent
  try {
    const roleId = await kv.get(env, 'absent_role_id');
    if (guildId && botToken && roleId) {
      await dFetch(`guilds/${guildId}/members/${target}/roles/${roleId}`, 'DELETE', null, botToken);
    }
  } catch (e) { console.warn('Retrait rôle Absent:', e.message); }

  // Basculer le tag du thread sur "Présent"
  try {
    const docs = await fsList(env, 'absences', 300);
    for (const d of docs) {
      const o = {};
      for (const k in (d.fields || {})) o[k] = fsToJs(d.fields[k]);
      if (o.agentId === target && o.threadId && presentTagId && botToken) {
        await dFetch(`channels/${o.threadId}`, 'PATCH', { applied_tags: [presentTagId] }, botToken).catch(() => {});
        break;
      }
    }
  } catch (e) { /* non bloquant */ }

  return json({ success: true });
}

// ── /api/absence/delete — un admin/superadmin supprime une absence ────
async function handleAbsenceDelete(request, env) {
  const { discordId, absenceId } = await request.json().catch(() => ({}));
  if (!(await isAdminOrDev(env, discordId))) return json({ error: 'Non autorisé — rôle admin requis' }, 403);
  if (!absenceId) return json({ error: 'absenceId requis' }, 400);

  try {
    const doc = await fsGet(env, 'absences', absenceId);
    if (doc) {
      const o = {};
      for (const k in (doc.fields || {})) o[k] = fsToJs(doc.fields[k]);
      // Supprimer le message Discord associé si connu (pas tout le thread — d'autres entrées peuvent y être)
      if (o.threadId && o.messageId) {
        const botToken = await kv.get(env, 'bot_token');
        if (botToken) {
          await dFetch(`channels/${o.threadId}/messages/${o.messageId}`, 'DELETE', null, botToken).catch(() => {});
        }
      }
    }
    await fsDelete(env, 'absences', absenceId);
    await logActivity(env, {
      type: 'absence',
      message: `Absence supprimée par ${discordId}`,
      actorId: discordId, ip: getClientIP(request),
      meta: { absenceId },
    });
    return json({ success: true });
  } catch (e) {
    return json({ error: e.message }, 500);
  }
}

// ── Auth modération : superadmin (DEV_ID) uniquement ──────────────
async function requireModAuth(env, discordId) {
  return isDev(env, discordId);
}

// ── /api/mod/warn ──────────────────────────────────────────────────
async function handleModWarn(request, env) {
  const { discordId, targetId, reason } = await request.json().catch(() => ({}));
  if (!(await requireModAuth(env, discordId))) return json({ error: 'Non autorisé' }, 403);
  if (!targetId || !reason) return json({ error: 'targetId et reason requis' }, 400);

  const botToken = await kv.get(env, 'bot_token');
  if (!botToken) return json({ error: 'bot_token non configuré' }, 404);

  // DM au membre (best-effort)
  try {
    const serverName = await getServerName(env);
    const dmChan = await dFetch('users/@me/channels', 'POST', { recipient_id: targetId }, botToken);
    if (dmChan.ok) {
      const dc = await dmChan.json();
      await dFetch(`channels/${dc.id}/messages`, 'POST', {
        embeds: [{ title: `⚠️ Avertissement — ${serverName}`, color: 0xff9f43, fields: [{ name: 'Raison', value: reason }] }],
      }, botToken);
    }
  } catch (e) { /* DMs fermés — non bloquant */ }

  await saveSanctionInternal(env, { type: 'warn', targetId, targetTag: targetId, moderatorId: discordId, moderatorTag: discordId, reason });
  await logModerationInternal(env, botToken, { action: 'AVERTISSEMENT', targetId, moderatorId: discordId, reason, color: 0xff9f43 });

  return json({ success: true });
}

// ── /api/mod/mute ────────────────────────────────────────────────
async function handleModMute(request, env) {
  const { discordId, targetId, reason, durationMs } = await request.json().catch(() => ({}));
  if (!(await requireModAuth(env, discordId))) return json({ error: 'Non autorisé' }, 403);
  if (!targetId || !reason || !durationMs) return json({ error: 'targetId, reason et durationMs requis' }, 400);

  const [guildId, botToken] = await Promise.all([kv.get(env, 'guild_id'), kv.get(env, 'bot_token')]);
  if (!guildId)  return json({ error: 'guild_id non configuré' }, 404);
  if (!botToken) return json({ error: 'bot_token non configuré' }, 404);

  const until = new Date(Date.now() + Math.min(durationMs, 28 * 86400000)).toISOString();
  const res = await dFetch(`guilds/${guildId}/members/${targetId}`, 'PATCH', { communication_disabled_until: until }, botToken);
  if (!res.ok) return json({ error: `Discord: ${await res.text()}` }, 500);

  await saveSanctionInternal(env, { type: 'mute', targetId, targetTag: targetId, moderatorId: discordId, moderatorTag: discordId, reason, duration: `${Math.round(durationMs/60000)}min` });
  await logModerationInternal(env, botToken, { action: 'MUTE', targetId, moderatorId: discordId, reason, color: 0xff4d6d });

  return json({ success: true, until });
}

// ── /api/mod/unmute ──────────────────────────────────────────────
async function handleModUnmute(request, env) {
  const { discordId, targetId } = await request.json().catch(() => ({}));
  if (!(await requireModAuth(env, discordId))) return json({ error: 'Non autorisé' }, 403);
  if (!targetId) return json({ error: 'targetId requis' }, 400);

  const [guildId, botToken] = await Promise.all([kv.get(env, 'guild_id'), kv.get(env, 'bot_token')]);
  if (!guildId || !botToken) return json({ error: 'guild_id/bot_token non configuré' }, 404);

  const res = await dFetch(`guilds/${guildId}/members/${targetId}`, 'PATCH', { communication_disabled_until: null }, botToken);
  if (!res.ok) return json({ error: `Discord: ${await res.text()}` }, 500);

  await saveSanctionInternal(env, { type: 'unmute', targetId, targetTag: targetId, moderatorId: discordId, moderatorTag: discordId, reason: 'Retrait manuel depuis le site' });
  return json({ success: true });
}

// ── /api/mod/kick ────────────────────────────────────────────────
async function handleModKick(request, env) {
  const { discordId, targetId, reason } = await request.json().catch(() => ({}));
  if (!(await requireModAuth(env, discordId))) return json({ error: 'Non autorisé' }, 403);
  if (!targetId || !reason) return json({ error: 'targetId et reason requis' }, 400);

  const [guildId, botToken] = await Promise.all([kv.get(env, 'guild_id'), kv.get(env, 'bot_token')]);
  if (!guildId || !botToken) return json({ error: 'guild_id/bot_token non configuré' }, 404);

  const res = await dFetch(`guilds/${guildId}/members/${targetId}`, 'DELETE', null, botToken);
  if (!res.ok) return json({ error: `Discord: ${await res.text()}` }, 500);

  await saveSanctionInternal(env, { type: 'kick', targetId, targetTag: targetId, moderatorId: discordId, moderatorTag: discordId, reason });
  await logModerationInternal(env, botToken, { action: 'EXPULSION', targetId, moderatorId: discordId, reason, color: 0xff4d6d });

  return json({ success: true });
}

// ── /api/mod/ban ─────────────────────────────────────────────────
async function handleModBan(request, env) {
  const { discordId, targetId, reason, deleteMessageDays } = await request.json().catch(() => ({}));
  if (!(await requireModAuth(env, discordId))) return json({ error: 'Non autorisé' }, 403);
  if (!targetId || !reason) return json({ error: 'targetId et reason requis' }, 400);

  const [guildId, botToken] = await Promise.all([kv.get(env, 'guild_id'), kv.get(env, 'bot_token')]);
  if (!guildId || !botToken) return json({ error: 'guild_id/bot_token non configuré' }, 404);

  const res = await dFetch(`guilds/${guildId}/bans/${targetId}`, 'PUT', {
    delete_message_seconds: (deleteMessageDays || 0) * 86400,
  }, botToken);
  if (!res.ok) return json({ error: `Discord: ${await res.text()}` }, 500);

  await saveSanctionInternal(env, { type: 'ban', targetId, targetTag: targetId, moderatorId: discordId, moderatorTag: discordId, reason });
  await logModerationInternal(env, botToken, { action: 'BANNISSEMENT', targetId, moderatorId: discordId, reason, color: 0xff0000 });

  return json({ success: true });
}

// ── /api/mod/softban ─────────────────────────────────────────────
async function handleModSoftban(request, env) {
  const { discordId, targetId, reason, deleteMessageDays } = await request.json().catch(() => ({}));
  if (!(await requireModAuth(env, discordId))) return json({ error: 'Non autorisé' }, 403);
  if (!targetId || !reason) return json({ error: 'targetId et reason requis' }, 400);

  const [guildId, botToken] = await Promise.all([kv.get(env, 'guild_id'), kv.get(env, 'bot_token')]);
  if (!guildId || !botToken) return json({ error: 'guild_id/bot_token non configuré' }, 404);

  const days = deleteMessageDays || 1;
  const banRes = await dFetch(`guilds/${guildId}/bans/${targetId}`, 'PUT', { delete_message_seconds: days * 86400 }, botToken);
  if (!banRes.ok) return json({ error: `Discord (ban): ${await banRes.text()}` }, 500);
  const unbanRes = await dFetch(`guilds/${guildId}/bans/${targetId}`, 'DELETE', null, botToken);
  if (!unbanRes.ok) return json({ error: `Discord (unban): ${await unbanRes.text()}` }, 500);

  await saveSanctionInternal(env, { type: 'softban', targetId, targetTag: targetId, moderatorId: discordId, moderatorTag: discordId, reason, duration: `Purge ${days}j` });
  await logModerationInternal(env, botToken, { action: 'SOFTBAN', targetId, moderatorId: discordId, reason, color: 0xff9f43 });

  return json({ success: true });
}

// ── /api/mod/unban ───────────────────────────────────────────────
async function handleModUnban(request, env) {
  const { discordId, targetId, reason } = await request.json().catch(() => ({}));
  if (!(await requireModAuth(env, discordId))) return json({ error: 'Non autorisé' }, 403);
  if (!targetId) return json({ error: 'targetId requis' }, 400);
  if (!/^\d{17,19}$/.test(targetId)) return json({ error: 'targetId invalide' }, 400);

  const [guildId, botToken] = await Promise.all([kv.get(env, 'guild_id'), kv.get(env, 'bot_token')]);
  if (!guildId || !botToken) return json({ error: 'guild_id/bot_token non configuré' }, 404);

  const res = await dFetch(`guilds/${guildId}/bans/${targetId}`, 'DELETE', null, botToken);
  if (!res.ok) return json({ error: `Discord: ${await res.text()}` }, 500);

  await saveSanctionInternal(env, { type: 'unban', targetId, targetTag: targetId, moderatorId: discordId, moderatorTag: discordId, reason: reason || 'Déban depuis le site' });
  return json({ success: true });
}

// ── Helpers internes modération ──────────────────────────────────
async function saveSanctionInternal(env, data) {
  try {
    await fsAdd(env, 'sanctions', { ...data, timestamp: new Date().toISOString() });
    const TYPE_LABEL = { warn: 'Avertissement', mute: 'Mute', unmute: 'Unmute', kick: 'Expulsion', ban: 'Bannissement', softban: 'Softban', unban: 'Déban' };
    await logActivity(env, {
      type: 'sanction',
      message: `${TYPE_LABEL[data.type] || data.type} sur ${data.targetTag || data.targetId} par ${data.moderatorTag || data.moderatorId}`,
      actorId: data.moderatorId || '', actorTag: data.moderatorTag || '',
      meta: { sanctionType: data.type, targetId: data.targetId, reason: data.reason },
    });
  } catch (e) { console.warn('saveSanctionInternal:', e.message); }
}
async function logModerationInternal(env, botToken, { action, targetId, moderatorId, reason, duration, color }) {
  try {
    const channelId = await kv.get(env, 'mod_log_channel_id');
    if (!channelId) return;
    const embed = {
      title: `🔨 ${action}`,
      color: color || 0xff4d6d,
      fields: [
        { name: '👤 Membre', value: `<@${targetId}>`, inline: true },
        { name: '👮 Modérateur', value: `<@${moderatorId}> *(depuis le site)*`, inline: true },
        ...(duration ? [{ name: '⏱ Durée', value: duration, inline: true }] : []),
        { name: '📝 Raison', value: reason || 'Aucune raison fournie' },
      ],
      timestamp: new Date().toISOString(),
    };
    await dFetch(`channels/${channelId}/messages`, 'POST', { embeds: [embed] }, botToken);
  } catch (e) { console.warn('logModerationInternal:', e.message); }
}

// ═══════════════════════════════════════════════════════════════
//  GESTION DES RÔLES DISCORD — réservé strictement au DEV_ID
// ═══════════════════════════════════════════════════════════════

// ── /api/roles/guild-info — liste tous les rôles + tous les membres ──
async function handleRolesGuildInfo(request, env) {
  const { discordId } = await request.json().catch(() => ({}));
  if (!isDev(env, discordId)) return json({ error: 'Non autorisé' }, 403);

  const [guildId, botToken] = await Promise.all([kv.get(env, 'guild_id'), kv.get(env, 'bot_token')]);
  if (!guildId || !botToken) return json({ error: 'guild_id/bot_token non configuré' }, 404);

  const rolesRes = await dFetch(`guilds/${guildId}/roles`, 'GET', null, botToken);
  if (!rolesRes.ok) return json({ error: `Discord (roles): ${await rolesRes.text()}` }, 500);
  const roles = (await rolesRes.json())
    .filter(r => r.name !== '@everyone')
    .sort((a, b) => b.position - a.position);

  // Pagination des membres (max 1000 par requête Discord)
  let members = [];
  let after = '0';
  for (let i = 0; i < 10; i++) { // sécurité : max 10 000 membres
    const mRes = await dFetch(`guilds/${guildId}/members?limit=1000&after=${after}`, 'GET', null, botToken);
    if (!mRes.ok) break;
    const batch = await mRes.json();
    if (!batch.length) break;
    members = members.concat(batch);
    if (batch.length < 1000) break;
    after = batch[batch.length - 1].user.id;
  }

  const membersOut = members.map(m => ({
    id: m.user.id,
    username: m.user.username,
    globalName: m.user.global_name || m.nick || m.user.username,
    avatar: m.user.avatar ? `https://cdn.discordapp.com/avatars/${m.user.id}/${m.user.avatar}.png` : null,
    roles: m.roles,
  }));

  return json({ roles, members: membersOut });
}

// ── /api/roles/presets/get — liste tous les presets enregistrés ────
async function handlePresetsGet(request, env) {
  const { discordId } = await request.json().catch(() => ({}));
  if (!isDev(env, discordId)) return json({ error: 'Non autorisé' }, 403);
  try {
    const docs = await fsList(env, 'role_presets', 100);
    const presets = docs.map(d => {
      const o = { id: d.name.split('/').pop() };
      for (const k in (d.fields || {})) o[k] = fsToJs(d.fields[k]);
      return o;
    });
    return json({ presets });
  } catch (e) {
    return json({ presets: [], error: e.message });
  }
}

// ── /api/roles/presets/save — crée ou met à jour un preset ────────
async function handlePresetsSave(request, env) {
  const { discordId, id, name, addRoleIds, removeRoleIds } = await request.json().catch(() => ({}));
  if (!isDev(env, discordId)) return json({ error: 'Non autorisé' }, 403);
  if (!name) return json({ error: 'name requis' }, 400);

  const data = {
    name,
    addRoleIds: addRoleIds || [],
    removeRoleIds: removeRoleIds || [],
    updatedAt: new Date().toISOString(),
  };

  try {
    if (id) {
      await fsPatch(env, 'role_presets', id, data);
      return json({ saved: true, id });
    } else {
      const created = await fsAdd(env, 'role_presets', data);
      const newId = created.name.split('/').pop();
      return json({ saved: true, id: newId });
    }
  } catch (e) {
    return json({ error: e.message }, 500);
  }
}

// ── /api/roles/presets/delete ──────────────────────────────────────
async function handlePresetsDelete(request, env) {
  const { discordId, id } = await request.json().catch(() => ({}));
  if (!isDev(env, discordId)) return json({ error: 'Non autorisé' }, 403);
  if (!id) return json({ error: 'id requis' }, 400);
  try {
    await fsDelete(env, 'role_presets', id);
    return json({ deleted: true });
  } catch (e) {
    return json({ error: e.message }, 500);
  }
}

// ── /api/roles/apply-preset — applique un preset à un membre ──────
// Ajoute addRoleIds, retire removeRoleIds. Ne touche jamais aux rôles
// de grade puisqu'un preset ne doit jamais les inclure — c'est au dev
// de gérer le grade séparément (rôle appliqué/retiré manuellement).
// Applique un ajout/retrait de rôle avec gestion du rate-limit Discord (429)
// ── Applique un preset ou une modif manuelle en UN SEUL appel Discord ──
// Discord permet de remplacer la liste complète des rôles d'un membre via
// PATCH /guilds/{guild}/members/{member} {roles:[...]} — ça évite la limite
// Cloudflare de sous-requêtes (50 max/invocation) qu'une boucle PUT/DELETE
// par rôle dépasserait vite sur un gros preset.
async function replaceMemberRoles(guildId, memberId, newRoles, botToken) {
  const r = await dFetch(`guilds/${guildId}/members/${memberId}`, 'PATCH', { roles: newRoles }, botToken);
  if (r.ok) return { ok: true };
  const errText = await r.text().catch(() => '');
  return { ok: false, status: r.status, error: errText };
}

async function handleApplyPreset(request, env) {
  const { discordId, memberId, presetId, currentRoles } = await request.json().catch(() => ({}));
  if (!isDev(env, discordId)) return json({ error: 'Non autorisé' }, 403);
  if (!memberId || !presetId) return json({ error: 'memberId et presetId requis' }, 400);
  if (!Array.isArray(currentRoles)) return json({ error: 'currentRoles requis (rôles actuels du membre)' }, 400);

  const [guildId, botToken] = await Promise.all([kv.get(env, 'guild_id'), kv.get(env, 'bot_token')]);
  if (!guildId || !botToken) return json({ error: 'guild_id/bot_token non configuré' }, 404);

  const presetDoc = await fsGet(env, 'role_presets', presetId);
  if (!presetDoc) return json({ error: 'Preset introuvable' }, 404);
  const preset = {};
  for (const k in (presetDoc.fields || {})) preset[k] = fsToJs(presetDoc.fields[k]);

  const addIds = preset.addRoleIds || [];
  const removeIds = preset.removeRoleIds || [];

  const newRoles = Array.from(new Set(
    currentRoles.filter(id => !removeIds.includes(id)).concat(addIds)
  ));

  const res = await replaceMemberRoles(guildId, memberId, newRoles, botToken);
  if (!res.ok) {
    return json({ error: `Discord (${res.status}): ${res.error || 'échec de la mise à jour des rôles'}` }, 500);
  }

  const added = addIds.filter(id => !currentRoles.includes(id));
  const removed = removeIds.filter(id => currentRoles.includes(id));
  await logActivity(env, {
    type: 'role',
    message: `Preset "${preset.name || presetId}" appliqué à ${memberId} par ${discordId} (+${added.length}/-${removed.length})`,
    actorId: discordId, ip: getClientIP(request),
    meta: { memberId, presetId, added, removed },
  });

  return json({ success: true, added, removed });
}

// ── /api/roles/apply-manual — ajout/retrait manuel d'un ou plusieurs rôles ──
async function handleApplyManual(request, env) {
  const { discordId, memberId, add, remove, currentRoles } = await request.json().catch(() => ({}));
  if (!isDev(env, discordId)) return json({ error: 'Non autorisé' }, 403);
  if (!memberId) return json({ error: 'memberId requis' }, 400);
  if (!Array.isArray(currentRoles)) return json({ error: 'currentRoles requis (rôles actuels du membre)' }, 400);

  const [guildId, botToken] = await Promise.all([kv.get(env, 'guild_id'), kv.get(env, 'bot_token')]);
  if (!guildId || !botToken) return json({ error: 'guild_id/bot_token non configuré' }, 404);

  const addIds = add || [];
  const removeIds = remove || [];

  const newRoles = Array.from(new Set(
    currentRoles.filter(id => !removeIds.includes(id)).concat(addIds)
  ));

  const res = await replaceMemberRoles(guildId, memberId, newRoles, botToken);
  if (!res.ok) {
    return json({ error: `Discord (${res.status}): ${res.error || 'échec de la mise à jour des rôles'}` }, 500);
  }

  const addedF = addIds.filter(id => !currentRoles.includes(id));
  const removedF = removeIds.filter(id => currentRoles.includes(id));
  await logActivity(env, {
    type: 'role',
    message: `Rôle(s) modifié(s) sur ${memberId} par ${discordId} (+${addedF.length}/-${removedF.length})`,
    actorId: discordId, ip: getClientIP(request),
    meta: { memberId, added: addedF, removed: removedF },
  });

  return json({ success: true, added: addedF, removed: removedF });
}

async function handleCheckRole(request, env) {
  const { accessToken } = await request.json().catch(() => ({}));
  if (!accessToken) return json({ hasRole: false, error: 'accessToken requis' }, 400);

  // 1) Identité VÉRIFIÉE : on demande à Discord à qui appartient ce token (on ignore tout ID envoyé par le navigateur)
  let me;
  try {
    const ur = await fetch(DISCORD_API + '/users/@me', { headers: { Authorization: 'Bearer ' + accessToken } });
    if (!ur.ok) return json({ hasRole: false, error: 'Token Discord invalide', code: 'bad_token' }, 401);
    me = await ur.json();
  } catch (e) { return json({ hasRole: false, error: 'Discord injoignable' }, 502); }
  if (!me?.id) return json({ hasRole: false, error: 'Identité introuvable' }, 401);

  // 2) Bannis : pas de session
  if (me.id !== env.DEV_ID && await isBanned(env, me.id)) {
    return json({ hasRole: false, banned: true, error: 'Accès définitivement refusé' }, 403);
  }

  // 3) Rôle Police dans le serveur
  const [guildId, pmRoleId] = await Promise.all([kv.get(env, 'guild_id'), kv.get(env, 'pm_role_id')]);
  let hasRole = false;
  if (guildId && pmRoleId) {
    try {
      const mr = await fetch(DISCORD_API + '/users/@me/guilds/' + guildId + '/member', { headers: { Authorization: 'Bearer ' + accessToken } });
      if (mr.ok) { const m = await mr.json(); hasRole = (m.roles || []).includes(pmRoleId); }
    } catch (e) { /* on continue sans le rôle */ }
  }

  // 4) Agent = rôle Police OU validé manuellement par un admin (champ approved) OU dev
  let approved = false;
  try { const u = await fsGet(env, 'users', me.id); approved = !!u && fsVal(u, 'approved') === true; } catch (e) {}
  const ag = hasRole || approved || me.id === env.DEV_ID;

  const token = await signSession(env, { id: me.id, u: me.username || '', ag, exp: Date.now() + SESSION_TTL_MS });
  return json({ hasRole, token, ag, discordId: me.id });
}

async function handleMaintenance(request, env) {
  const { discordId } = await request.json().catch(() => ({}));
  const doc = await fsGet(env, 'config', 'maintenance');
  return json({
    active:         doc ? (fsVal(doc,'active') === true) : false,
    reason:         doc ? fsVal(doc,'reason') || '' : '',
    endTime:        doc ? fsVal(doc,'endTime') || '' : '',
    scheduledStart: doc ? fsVal(doc,'scheduledStart') || '' : '',
    scheduledEnd:   doc ? fsVal(doc,'scheduledEnd') || '' : '',
    isOwner:        isDev(env, discordId),
  });
}

// ── /api/maintenance/save — dev only ─────────────────────────────
async function handleMaintenanceSave(request, env) {
  const { discordId, data } = await request.json();
  if (!isDev(env, discordId)) return json({ error: 'Non autorisé' }, 403);
  await fsPatch(env, 'config', 'maintenance', data);
  await logActivity(env, {
    type: 'maintenance',
    message: `Maintenance ${data?.active ? 'activée' : 'désactivée/modifiée'} par ${discordId}`,
    actorId: discordId, ip: getClientIP(request),
  });
  return json({ saved: true });
}

// ── /api/secrets/get — dev only, masqué ──────────────────────────
async function handleSecretsGet(request, env) {
  const { discordId } = await request.json();
  if (!isDev(env, discordId)) return json({ error: 'Non autorisé' }, 403);
  const keys = ['bot_token','forum_id','pm_role_id','guild_id','channel_pvi_id','channel_fpr_id','channel_saisies_obj_id','channel_saisies_vl_id','bot_api_url','forum_absences_id','mod_log_channel_id','panel_channel_id','server_name','logo_url'];
  const res  = {};
  for (const k of keys) { const v = await kv.get(env,k); res[k] = { configured: !!v, preview: v ? mask(v) : '' }; }
  return json({ secrets: res });
}

// ── /api/secrets/save — dev only ─────────────────────────────────
async function handleSecretsSave(request, env) {
  const { discordId, secrets } = await request.json();
  if (!isDev(env, discordId)) return json({ error: 'Non autorisé' }, 403);
  const allowed = ['bot_token','forum_id','pm_role_id','guild_id','channel_pvi_id','channel_fpr_id','channel_saisies_obj_id','channel_saisies_vl_id','bot_api_url','forum_absences_id','mod_log_channel_id','panel_channel_id','server_name','logo_url'];
  const saved = [];
  for (const k of allowed) {
    if (!secrets[k]) continue;
    if (k.startsWith('channel_') && !/^\d{17,19}$/.test(secrets[k]))
      return json({ error: `ID de salon invalide pour ${k}` }, 400);
    if (k === 'bot_api_url' && !secrets[k].startsWith('https://'))
      return json({ error: 'bot_api_url doit être une URL https valide' }, 400);
    await kv.set(env, k, secrets[k]);
    saved.push(k);
  }
  if (saved.length) {
    await logActivity(env, {
      type: 'config',
      message: `Configuration modifiée par ${discordId} (${saved.join(', ')})`,
      actorId: discordId, ip: getClientIP(request),
      meta: { changedKeys: saved },
    });
  }
  return json({ saved });
}

// ── /api/codes/get — dev only ─────────────────────────────────────
// ── Firestore <-> JS conversion générique (supporte objets/tableaux imbriqués) ──
function fsToJs(v) {
  if (v.stringValue !== undefined) return v.stringValue;
  if (v.integerValue !== undefined) return parseInt(v.integerValue);
  if (v.doubleValue !== undefined) return v.doubleValue;
  if (v.booleanValue !== undefined) return v.booleanValue;
  if (v.nullValue !== undefined) return null;
  if (v.arrayValue !== undefined) return (v.arrayValue.values || []).map(fsToJs);
  if (v.mapValue !== undefined) {
    const o = {};
    for (const k in (v.mapValue.fields || {})) o[k] = fsToJs(v.mapValue.fields[k]);
    return o;
  }
  return null;
}
function jsToFs(v) {
  if (v === null || v === undefined) return { nullValue: null };
  if (typeof v === 'number') return Number.isInteger(v) ? { integerValue: v } : { doubleValue: v };
  if (typeof v === 'boolean') return { booleanValue: v };
  if (Array.isArray(v)) return { arrayValue: { values: v.map(jsToFs) } };
  if (typeof v === 'object') return { mapValue: { fields: Object.fromEntries(Object.entries(v).map(([k, val]) => [k, jsToFs(val)])) } };
  return { stringValue: String(v) };
}

// ── /api/codes/get — dev only ─────────────────────────────────────
async function handleCodesGet(request, env) {
  const { discordId } = await request.json();
  if (!isDev(env, discordId)) return json({ error: 'Non autorisé' }, 403);
  const [p, r] = await Promise.all([fsGet(env,'codes','penal'), fsGet(env,'codes','route')]);
  const parse = doc => {
    if (!doc?.fields?.articles) return [];
    return (doc.fields.articles.arrayValue?.values || []).map(fsToJs);
  };
  return json({ penal: parse(p), route: parse(r) });
}

// ── /api/codes/save — dev only ────────────────────────────────────
async function handleCodesSave(request, env) {
  const { discordId, type, articles } = await request.json();
  if (!isDev(env, discordId)) return json({ error: 'Non autorisé' }, 403);
  if (!['penal','route'].includes(type)) return json({ error: 'type invalide' }, 400);
  const arrVal = { arrayValue: { values: articles.map(jsToFs) } };
  const fields = { articles: arrVal, updatedAt: { stringValue: new Date().toISOString() } };
  const m = 'updateMask.fieldPaths=articles&updateMask.fieldPaths=updatedAt';
  const r = await fetch(`${fbBase(env)}/codes/${type}?${m}&key=${fbKey(env)}`, {
    method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ fields }),
  });
  if (!r.ok) throw new Error(`codes/save ${r.status}: ${await r.text()}`);
  await logActivity(env, {
    type: 'config',
    message: `Code ${type === 'penal' ? 'pénal' : 'route'} modifié par ${discordId} (${articles.length} article(s))`,
    actorId: discordId, ip: getClientIP(request),
  });
  return json({ saved: true, count: articles.length });
}

// ── /api/codes/public — lecture publique (pas d'auth requise) ────
// Utilisé par app.html, fpr.html, code-penal.html, code-route.html
async function handleCodesPublic(request, env) {
  const [p, r] = await Promise.all([fsGet(env,'codes','penal'), fsGet(env,'codes','route')]);
  const parse = doc => {
    if (!doc?.fields?.articles) return [];
    return (doc.fields.articles.arrayValue?.values || []).map(fsToJs);
  };
  return json({ penal: parse(p), route: parse(r) });
}

// ── Discord fetch helper ──────────────────────────────────────────
function dFetch(ep, method, body, token) {
  const opts = { method, headers: { 'Authorization': `Bot ${token}`, 'Content-Type': 'application/json' } };
  if (body !== null) opts.body = JSON.stringify(body);
  return fetch(`${DISCORD_API}/${ep}`, opts);
}

function json(data, status = 200) {
  return new Response(JSON.stringify(data), { status, headers: { ...CORS, 'Content-Type': 'application/json' } });
}
